package dao;
import db.DBConnection;
import java.sql.*;
import java.util.*;

public class DestinationDAO {
    public static List<String> getAll() {
        List<String> list = new ArrayList<>();
        try {
            ResultSet rs = DBConnection.getConnection()
                .createStatement()
                .executeQuery("SELECT name FROM destination");
            while (rs.next()) {
                list.add(rs.getString("name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
