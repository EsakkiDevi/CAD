package dao;
import db.DBConnection;
import java.sql.*;

public class EmployeeDAO {
    public static ResultSet getAllEmployees() throws Exception {
        String sql = "SELECT e.id,e.name,e.email,d.name AS dest " +
                     "FROM employee e JOIN destination d ON e.dest_id=d.id";
        return DBConnection.getConnection()
                .createStatement()
                .executeQuery(sql);
    }
}
