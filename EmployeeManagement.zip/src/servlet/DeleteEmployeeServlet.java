package servlet;
import db.DBConnection;
import javax.servlet.http.*;
import java.io.IOException;

public class DeleteEmployeeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        try {
            int id = Integer.parseInt(req.getParameter("id"));
            DBConnection.getConnection()
                .createStatement()
                .executeUpdate("DELETE FROM employee WHERE id=" + id);
            resp.sendRedirect("HomeServlet");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
