package servlet;
import db.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class SaveEmployeeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String dest = req.getParameter("destination");

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps1 =
                con.prepareStatement("SELECT id FROM destination WHERE name=?");
            ps1.setString(1, dest);
            ResultSet rs = ps1.executeQuery();
            rs.next();
            int destId = rs.getInt(1);

            PreparedStatement ps =
                con.prepareStatement(
                    "INSERT INTO employee(name,email,dest_id) VALUES(?,?,?)");
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setInt(3, destId);
            ps.executeUpdate();

            resp.sendRedirect("HomeServlet");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
